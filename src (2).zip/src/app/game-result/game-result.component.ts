import { Component } from '@angular/core';

@Component({
  selector: 'app-game-result',
  standalone: true,
  imports: [],
  templateUrl: './game-result.component.html',
  styleUrl: './game-result.component.scss'
})
export class GameResultComponent {

}
