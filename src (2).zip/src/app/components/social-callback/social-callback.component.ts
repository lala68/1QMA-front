import { Component } from '@angular/core';

@Component({
  selector: 'app-social-callback',
  standalone: true,
  imports: [],
  templateUrl: './social-callback.component.html',
  styleUrl: './social-callback.component.scss'
})
export class SocialCallbackComponent {

  constructor() {
  }

}
