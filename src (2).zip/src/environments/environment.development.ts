export const environment = {
  baseUrl : 'https://api.staging.1qma.games/'
};
