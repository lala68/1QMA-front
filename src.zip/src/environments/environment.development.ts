export const environment = {
  baseUrl : 'http://staging.api.1qma.games/'
};
